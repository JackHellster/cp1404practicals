import random
print(random.randint(5, 20))  # line 1 smallest number is 5, largest is 19
print(random.randrange(3, 10, 2))  # line 2 smallest is 3, largest is 9
print(random.uniform(2.5, 5.5))  # line 3 smallest is 2.50, largest is 5.4999999999999
print(random.randint(2,100))


